CTGP Revolution May 5th beta version!

Thanks for downloading this beta version of CTGP. To get started, extract the files from
this ZIP archive to the root of your SD card (or drag/drop all of the files onto the SD)
and load up the CTGP Revolution Channel. It will tell you that there are two updates
available. Do these updates and you will be updated to the beta version! After these updates
install, there may be more updates to get over the automatic updater. This is fine, let
those download too, as the may contain bugfixes and other handy additions.

This beta version contains many new code features, but no new tracks. The new code features
are as follows:

- LAN multiplayer mode (accessible on settings page 2)
- Item Rain for offline, friend rooms and LAN multiplayer (pages 3 and 5 of settings)
- All Items Can Land for offline, friend rooms and LAN (pages 3 and 5 of settings)
- High data rate mode for friend rooms (page 5 of settings, always on in LAN mode)
- Item boxes disabled mode for friend rooms and LAN multiplayer (page 5 of settings)
- Various bugfixes to the CTGP-R Channel, and a clearer ghost database connection interface

Please note that this is a beta version and therefore there may be more updates than usual.
It also may contain bugs that a normal version of CTGP would not. Please report any
unexpected occurances to MrBean35000vr. If you use CTGP for competitive purposes, it might
be wise to run two versions at once, which you can do by backing up blob.bin from the ctgpr
folder on the SD card before updating, and swapping it in and out with the one that is
generated after updating. Please check the rules of any rooms you may be joining when
choosing which version to use.


Known bugs:

- Rarely in offline mode, item rain will cause glitchy triangles to obscure parts of the
  screen. These seem to go away on their own after a little bit.
- Sometimes in online, item rain causes glitchy translucent grey triangles to appear briefly
  every now and again. These seem to be a harmless visual quirk.
- All items can land has the side effect of removing restrictions from ordinarily restricted
  items (making it so multiple people can hold shocks, bullets, etc). This may be turned into
  a feature rather than a bug, but strictly speaking it's unintended behaviour.
- Item rain may have stability issues in rooms above 8 players because we haven't had an
  opportunity to test it yet.
- LAN multiplayer may freeze if you disconnect due to not making inputs. While we haven't
  seen that bug lately, we think it still exists. Please tell us if you encounter it!
- We haven't added any languages other than English to the channel or to LAN multiplayer
  interfaces.